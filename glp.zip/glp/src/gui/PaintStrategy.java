package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.util.List;

import configuration.SimulationConfiguration;
import element.Obstacle;
import element.Source;
import element.Souris;
import map.Block;
import map.Grille;


public class PaintStrategy {
	public void paint(Grille grille, Graphics graphics) {
		int blockSize = SimulationConfiguration.BLOCK_SIZE;
		Block[][] blocks = grille.getBlocks();

		for (int lineIndex = 0; lineIndex < grille.getLignesCount(); lineIndex++) {
			for (int columnIndex = 0; columnIndex < grille.getColonnesCount(); columnIndex++) {
				Block block = blocks[lineIndex][columnIndex];

				if ((lineIndex + columnIndex) % 2 == 0) {
					graphics.setColor(Color.GRAY);
					graphics.fillRect(block.getColonne() * blockSize, block.getLigne() * blockSize, blockSize, blockSize);
				}
			}
		}
	}

	public void paint(Souris souris, Graphics graphics) {
		Block position = souris.getPosition();
		int blockSize = SimulationConfiguration.BLOCK_SIZE;

		int y = position.getLigne();
		int x = position.getColonne();

		graphics.setColor(Color.BLACK);
		graphics.fillOval(x * blockSize, y * blockSize, blockSize, blockSize);

	}

	public void paint(Obstacle obstacle, Graphics graphics) {
		Block position = obstacle.getPosition();
		int blockSize = SimulationConfiguration.BLOCK_SIZE;

		int y = position.getLigne();
		int x = position.getColonne();

		graphics.setColor(Color.RED);
		graphics.fillOval(x * blockSize, y * blockSize, blockSize, blockSize);
	}

	public void paint(Source source, Graphics graphics) {
		Block position = source.getPosition();
		int blockSize = SimulationConfiguration.BLOCK_SIZE;

		int y = position.getLigne();
		int x = position.getColonne();

		graphics.setColor(Color.YELLOW);
		graphics.fillRect(x * blockSize + blockSize /3, y * blockSize, blockSize/3, blockSize);
	}
}