package element;

public class Diffuser {
	private String diffuser;
	/*String egoiste or cooperative*/
	public Diffuser(String diffuser) {
		this.diffuser=diffuser;
	}
	public String getDiffuser() {
		return diffuser;
	}
}