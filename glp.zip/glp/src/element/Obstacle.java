package element;

import map.Block;
import duree.Tours;

public class Obstacle extends Element{
	private String type;
	/*String mur, piege or source*/
	public Obstacle(Block position,String type) {
		super(position);
		this.type=type;
	}
	public String getType() {
		return type;
	}
	public void effect(Obstacle obs, SourisNourriture nourriture, Tours nombreTours) {
		if(obs.getType() == "piege") {
			nourriture.decrement(); //perd une unit� de nourriture (ou plus) si c'est un pi�ge
		}
		if(obs.getType() == "mur") {
			nombreTours.increment(); //passe au tour suivant si tombe sur un mur
		}
		if(obs.getType() == "source") {
			nourriture.increment(); //gagne de la nourriture si c'est une source
		}
	}
}