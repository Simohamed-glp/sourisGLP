package element;

public class Informations {

}