package element;

public class Nourriture {
	private int unite;

	public Nourriture(int unite) {
		this.unite = unite;
	}
	public void incrementer() {
		unite++;
	}
	public void decrementer() {
		unite--;
	}
}