package duree;

import java.util.ArrayList;
import java.util.Iterator;

import element.Souris;

public class Tours {
	private int nombreTours;
	private int nourriture;
	private Population population;
	private ArrayList<Souris> souris;
	
	public Tours(int nombreTours) {
		this.nombreTours=nombreTours;
	}
	public void exterminatePopulation() {
		if(population.index()==0) {
			nombreTours=0;
		}
	}
	public int getNombreTours() {
		return nombreTours;
	}
	public void increment() {
		nombreTours++;
		int i = 0;
		for(Iterator<Souris> it=souris.iterator();it.hasNext();) {
			souris.get(i).setNourriture(nourriture--); //a chaque tour, les souris perdent une unit�
		}
	}
}