package map;

public class Carte {
	private Carte carte;
	private Grille grille;
	public Carte() {
		
	}
}