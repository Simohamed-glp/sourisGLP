package element;

import java.util.ArrayList;

public class Memoire {
	private ArrayList<Informations> informations;
}
