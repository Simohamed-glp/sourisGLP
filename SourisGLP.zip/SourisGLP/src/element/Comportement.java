package element;

public class Comportement {
	private Communication communication;
	private Sociabilite sociabilite;
	public Comportement(Communication communication, Sociabilite sociabilite) {
		this.communication = communication;
		this.sociabilite = sociabilite;
	}
	
}
