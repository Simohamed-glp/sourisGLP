package element;

public class Sociabilite{
	private int valeurSociabilite;

	public Sociabilite(int valeurSociabilite) {
		this.valeurSociabilite = valeurSociabilite;
	}

}
