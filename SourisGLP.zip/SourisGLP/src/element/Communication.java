package element;

public class Communication {
	private Diffuser diffuser;
	private Receptionner receptionner;
	public Communication(Diffuser diffuser, Receptionner receptionner) {
		this.diffuser = diffuser;
		this.receptionner = receptionner;
	}
}
