package element;

import java.util.ArrayList;

public class SourisNourriture {
	private int nourriture;
	public SourisNourriture(int nourriture){
		this.nourriture=nourriture;
	}
	public int getUniteNourriture() {
		return nourriture;
	}
	
}
